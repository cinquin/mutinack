No test source yet, however the folder is required for java comment preprocessor
Otherwise it fails with

[ERROR] Failed to execute goal com.igormaznitsa:jcp:6.0.1:preprocess (preprocessTestSources) on project pgjdbc-benchmark: Can't find a source directory [/home/travis/build/pgjdbc/pgjdbc/ubenchmark/src/test/java] -> [Help 1]
