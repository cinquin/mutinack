/*
 * Copyright (c) 2004, PostgreSQL Global Development Group
 * See the LICENSE file in the project root for more information.
 */

package org.postgresql.test.sspi;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/*
 * Executes all known tests for SSPI.
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({ SSPITest.class })
public class SSPITestSuite {
  // Empty.
}
